<template>
  <div class="authority-management-tool">
    <el-button type="primary" icon="el-icon-plus">新 增</el-button>
  </div>
</template>
