<template>
  <div class="g-sign-logo">
    <img src="../../assets/img/logo.png" class="absolute-center" />
  </div>
</template>

<style lang="scss">
.g-sign-logo {
  width: 330px;
  height: 48px;
  position: relative;
  img {
    width: 308px;
  }
}
</style>
