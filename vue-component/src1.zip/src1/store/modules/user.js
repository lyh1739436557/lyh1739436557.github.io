const state = {
  u: 'admin',
  p: 'admin'
}
const getters = {}
const mutations = {}
const actions = {}

export default {
  state,
  getters,
  mutations,
  actions
}
