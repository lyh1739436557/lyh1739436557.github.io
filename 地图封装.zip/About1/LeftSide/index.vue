<template>
  <div class="person-left-side">
    <div class="person-left-side-top">
      <div class="total-people">
        <div class="go-out-people">
            <div class="people-left">
              今日出人口<span class="people-left-num">19003</span> <span class="people-left-msg">人</span>
            </div>
            <div class="people-right">
              <span>环比上小时<span class="people-up">+15%</span></span>
              <span>环比昨日同期<span class="people-down">-10%</span></span>
            </div>
        </div>
        <div class="go-in-people">
            <div class="people-left">
              今日入人口<span class="people-left-num">39033</span> <span class="people-left-msg">人</span>
            </div>
            <div class="people-right">
              <span>环比上小时<span class="people-up">+15%</span></span>
              <span>环比昨日同期<span class="people-down">-10%</span></span>
            </div>
        </div>
      </div>
      <div class="person-list">
        <people-lists></people-lists>
      </div>
      <div class="person-echart">
        <people-echarts></people-echarts>
      </div>
    </div>
    <div class="person-left-side-bottom">
      <people-dsb></people-dsb>
      <people-photo></people-photo>
    </div>
  </div>
</template>

<script>
import peopleLists from './components/peopleLists';
import peopleEcharts from './components/peopleEcharts';
import peopleDsb from './components/peopleDsb';
import peoplePhoto from './components/peoplePhoto';
export default {
  components: {
    peopleLists,
    peopleEcharts,
    peopleDsb,
    peoplePhoto
  }
}
</script>

<style lang="scss">
  .person-left-side{
    width: 1114px;
    height: 100%;
    // background: pink;
    margin: 0 24px 0 50px;
    &-top{
      margin-top: 10px;
      height: 508px;
      background: url('../img/100box.png') no-repeat;
      background-size: 100% 100%;
      .total-people{
        display: flex;
        align-items: center;
        margin: 0 20px 0 20px;
        .go-out-people, .go-in-people{
          flex: 1;
          height: 80px;
          background: url('../img/101box.png') no-repeat;
          background-size: 100% 100%;
          margin-top: 50px;
          display: flex;
          align-items: center;
          padding-left: 20px;
          .people-left{
            font-size:21px;
            font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
            font-weight:bold;
            color:rgba(255,255,255,0.9);
            display: flex;
            align-items: center;
            &-num{
              font-size:42px;
              font-family:DINAlternate-Bold,DINAlternate;
              font-weight:bold;
              color:rgba(1,213,255,1);
              margin: 0 7px;
            }
            &-msg{
              font-size:14px;
              font-family:PingFangSC-Regular,PingFang SC;
              font-weight:400;
              color:rgba(255,255,255,0.7);
            }
          }
          .people-right{
            display: flex;
            flex-direction: column;
            font-size:16px;
            font-family:PingFangSC-Medium,PingFang SC;
            font-weight:500;
            color:rgba(255,255,255,0.7);
            flex: 1;
            text-align: right;
            margin-right: 40px;
            .people-up{
              font-size:18px;
              font-family:DINAlternate-Bold,DINAlternate;
              font-weight:bold;
              color:rgba(255,89,89,1);
              margin-left: 20px;
            }
            .people-down{
              font-size:18px;
              font-family:DINAlternate-Bold,DINAlternate;
              font-weight:bold;
              color:rgba(102,204,170,1);
              margin-left: 24px;
            }
          }
        }
        .go-in-people{
          margin-left: 19px;
          margin-top: 50px;
        }
      }
      .person-list{
        margin: 20px 20px 24px;
      }
      .person-echart{
        margin: 0 20px;
      }
    }
    &-bottom{
      height: 423px;
      background: url('../img/200box.png') no-repeat;
      background-size: 100% 100%;
      margin-top: 28px;
    }
  }
</style>
