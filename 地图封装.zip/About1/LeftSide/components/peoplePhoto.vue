<template>
    <div class="people-face">
        <div class="people-face-title">
            <div>重点小区、区域</div>
            <div>人脸感知</div>
            <div>重点人员发现</div>
        </div>
        <div v-for="item in new Array(4)" :key="item" class="people-face-item">
            <img class="people-face-item-img" src="" alt="">
            <div class="people-face-item-introduce">
                <div class="introduce-index">
                    <img class="introduce-index-img" src="../../img/203icon.png" alt="">
                    <span>重点人员</span>
                </div>
                <div>宋伟</div>
                <div>中福花园二期</div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
    .people-face{
        margin: 27px 29px 0 23px;
        display: flex;
        align-items: center;
        &-title{
            width:196px;
            height:100px;
            background: url('../../img/203title.png') no-repeat;
            background-size: 100% 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 29px;
            font-size:18px;
            font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
            font-weight:bold;
            color:rgba(184,212,230,1);
            margin-right: 20px;
        }
        &-item{
            width: 195px;
            height: 106px;
            background: url('../../img/203box.png') no-repeat;
            background-size: 100% 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 25px;
            &-img{
                width:72px;
                height:96px;
                border: 1px solid #ddd;
            }
            &-introduce{
                margin-left: 9px;
                font-size:14px;
                font-family:MicrosoftYaHei;
                color:rgba(184,212,230,1);
                line-height: 1.7;
                .introduce-index{
                    display: flex;
                    align-items: center;
                    color:rgba(255,89,89,1);
                    &-img{
                        width: 18px;
                        height: 18px;
                        margin-right: 9px;
                    }
                }
            }
        }
    }
</style>


