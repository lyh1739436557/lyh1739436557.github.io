<template>
    <div class="people-dsb">
        <div class="people-dsb-left">
            <div class="people-dsb-left-title">人口分布及24小时流动趋势</div>
            <div class="people-dsb-chart">
                <div class="people-dsb-chart-bar">
                    <div v-for=" item in barData" :key="item.id" class="people-dsb-chart-bar-item">
                        <div class="bar-item-title">
                            {{item.name}}
                        </div>
                        <div class="bar-item-bg">
                            <div class="bar-item-color" :style="{width: item.num/totalPeople*100 + '%' }"></div>
                        </div>
                        <div class="bar-item-num">
                            <span>{{(item.num/10000).toFixed(2)}}</span>
                            <span>万</span>
                        </div>
                    </div>
                </div>
                <div class="people-dsb-chart-line" ref="chart-line">
                    
                </div>
            </div>
        </div>
        <div class="people-dsb-right">
            <div class="people-dsb-right-title">人口分布及24小时流动趋势</div>
            <div class="people-dsb-right-list">
                <dv-scroll-board class="scroll-list" :config="config" style="height:174px" />
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            totalPeople: 0,
            barData:[
                {
                    name:'居住人口',
                    id: 1,
                    num: 878789
                },
                {
                    name:'工作人口',
                    id: 2,
                    num: 653283
                },
                {
                    name:'境外人口',
                    id: 3,
                    num: 190238
                },
            ],
            myChart:null,
            config:{
                data: [
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','外滩区域', '<span style="color:#5DE9F8">进35621人</span>', '<span style="color:#B8D4E6">出35611人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','豫园商城', '<span style="color:#5DE9F8">进52995人</span>', '<span style="color:#B8D4E6">出51886人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','中福一期', '<span style="color:#5DE9F8">进3651人</span>', '<span style="color:#B8D4E6">出3251人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','中福二期', '<span style="color:#5DE9F8">进2011人</span>', '<span style="color:#B8D4E6">出6523人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','民生银行大厦', '<span style="color:#5DE9F8">进6551人</span>', '<span style="color:#B8D4E6">出5214人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','金陵大厦', '<span style="color:#5DE9F8">进5661人</span>', '<span style="color:#B8D4E6">出5221人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','福申大厦', '<span style="color:#5DE9F8">进6211人</span>', '<span style="color:#B8D4E6">出4899人</span>']
                ],
                oddRowBGC: 'rgba(21,66,116,0.15)',
                evenRowBGC: 'rgba(21,66,116,0.3)',
                rowNum: 4,
                columnWidth: [20],
                // index: true
            }
        }
    },
    mounted(){
        this.totalPeople = this.barData[0].num + this.barData[1].num + this.barData[2].num
        this.drawLine();
    },
    methods:{
        drawLine(){
            this.myChart = this.$echarts.init(this.$refs['chart-line']);
            let option = this.getOption();
            window.onresize = this.myChart.resize;
            this.myChart.setOption(option);
        },
        getOption(){
            let option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#57617B'
                        }
                    }
                },
                grid: {
                    left: 0,
                    right: 20,
                    top: '20%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLine: {
                        lineStyle: {
                            color: '#57617B'
                        }
                    },
                    data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                }],
                yAxis: [{
                    type: 'value',
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false
                    },
                    axisLabel: {
                        margin: 10,
                        textStyle: {
                            fontSize: 14
                        }
                    },
                    splitLine: {
                        show:false
                    }
                }],
                series: [{
                    // name: '南宁-曼芭',
                    type: 'line',
                    smooth: true,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#01DAFF'
                        }
                    },
                    data: [96.3,96.4,97.5,95.6,98.1,94.8,89.6,94.1,80.1,52.4,75.8,94.7]
                }, {
                    // name: '桂林-曼芭',
                    type: 'line',
                    smooth: true,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#4E80FF'
                        }
                    },
                    data: [97.3,99.2,99.3,100.0,99.6,90.6,80.0,91.5,69.8,67.5,90.4,84.9]
                }, {
                    // name: '南宁-甲米',
                    type: 'line',
                    smooth: true,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#B8D4E6'
                        }
                    },
                    data: [84.2,81.0,67.5,72.1,43.7,88.5,91.9,101.8,79.7,87.6,92.9,0]
                }, ]
            };
            return option
        }
    }
}
</script>
<style lang="scss" scoped>
    .people-dsb{
        display: flex;
        margin: 0 29px;
        &-left{
            flex: 1;
            &-title{
                height: 36px;
                line-height: 36px;
                font-size:18px;
                font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                font-weight:bold;
                color:rgba(184,212,230,1);
                background: url('../../img/103-4title.png') no-repeat;
                background-size: 100% 100%;
                margin-top: 48px;
                padding-left: 20px;
            }
            .people-dsb-chart{
                &-bar{
                    &-item{
                        display: flex;
                        align-items: center;
                        margin-top: 6px;
                        &:first-child{
                            margin-top: 9px;
                        }
                        .bar-item-title{
                            height: 22px;
                            line-height: 22px;
                            flex: 1;
                            padding-left: 29px;
                            background: url('../../img/201path.png') no-repeat;
                            background-size: 100% 100%;
                            font-size:12px;
                            font-family:MicrosoftYaHeiSemibold;
                            color:rgba(255,255,255,1);
                        }
                        .bar-item-bg{
                            width:325px;
                            height:8px;
                            background:rgba(21,66,116,0.3);
                            position: relative;
                            margin: 0 10px;
                            line-height: 8px;
                            .bar-item-color{
                                position: absolute;
                                top: 0;
                                bottom: 0;
                                // width:60%;
                                height:8px;
                                background:rgba(93,233,248,0.57);
                            }
                        }
                        .bar-item-num{
                            flex: 1;
                            span{
                                &:first-child{
                                    font-size:18px;
                                    font-family:DINAlternate-Bold,DINAlternate;
                                    font-weight:bold;
                                    color:rgba(204,236,255,1);
                                }
                                &:last-child{
                                    font-size:12px;
                                    font-family:MicrosoftYaHei;
                                    color:rgba(255,255,255,0.8);
                                    margin-left: 10px;
                                }
                            }
                        }
                        &:nth-child(2){
                            .bar-item-bg{
                                .bar-item-color{
                                    background:rgba(78,128,255,1);
                                }
                            }
                        }
                        &:nth-child(3){
                            .bar-item-bg{
                                .bar-item-color{
                                    background:rgba(184,212,230,1);
                                }
                            }
                        }
                    }
                }
                &-line{
                    height: 97px;
                    width: 100%;
                }
            }
        }
        &-right{
            flex: 1;
            &-title{
                height: 36px;
                line-height: 36px;
                margin-left: 17px;
                padding-left: 20px;
                font-size:18px;
                font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                font-weight:bold;
                color:rgba(184,212,230,1);
                background: url('../../img/103-4title.png') no-repeat;
                background-size: 100% 100%;
                margin-top: 48px;
            }
            &-list{
                margin-top: 12px;
                margin-left: 23px;
            }
        }
    }
</style>

