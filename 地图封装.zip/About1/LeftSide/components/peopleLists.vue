<template>
    <div class="people-list">
        <div class="people-list-left">
            <div class="people-list-title">
                与外区边界重点道路路口实时人流分析
            </div>
            <dv-scroll-board class="scroll-list" :config="config" style="height:74px" />
        </div>
        <div class="people-list-right">
            <div class="people-list-title">
                与外区边界重点道路路口实时人流分析
            </div>
            <dv-scroll-board class="scroll-list" :config="config1" style="height:74px" />
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            config:{
                data: [
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','外白渡桥', '<span style="color:#5DE9F8">进205622人</span>', '<span style="color:#B8D4E6">出302154人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','四川路桥', '<span style="color:#5DE9F8">进198521人</span>', '<span style="color:#B8D4E6">出205644人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','河南路桥', '<span style="color:#5DE9F8">进184319人</span>', '<span style="color:#B8D4E6">出256114人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','福建路桥', '<span style="color:#5DE9F8">进359844人</span>', '<span style="color:#B8D4E6">出403094人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','浙江路桥', '<span style="color:#5DE9F8">进265114人</span>', '<span style="color:#B8D4E6">出305454人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','山西路桥', '<span style="color:#5DE9F8">进205622人</span>', '<span style="color:#B8D4E6">出302154人</span>']
                ],
                oddRowBGC: 'rgba(21,66,116,0.15)',
                evenRowBGC: 'rgba(21,66,116,0.3)',
                rowNum: 2,
                columnWidth: [20],
                // index: true
            },
            config1:{
                data: [
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','外滩区域', '<span style="color:#5DE9F8">进35621人</span>', '<span style="color:#B8D4E6">出35611人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','豫园商城', '<span style="color:#5DE9F8">进52995人</span>', '<span style="color:#B8D4E6">出51886人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','中福一期', '<span style="color:#5DE9F8">进3651人</span>', '<span style="color:#B8D4E6">出3251人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','中福二期', '<span style="color:#5DE9F8">进2011人</span>', '<span style="color:#B8D4E6">出6523人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','民生银行大厦', '<span style="color:#5DE9F8">进6551人</span>', '<span style="color:#B8D4E6">出5214人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','金陵大厦', '<span style="color:#5DE9F8">进5661人</span>', '<span style="color:#B8D4E6">出5221人</span>'],
                    ['<div style="width:6px;height:6px;background:#B8D4E6;margin-top:15px"></div>','福申大厦', '<span style="color:#5DE9F8">进6211人</span>', '<span style="color:#B8D4E6">出4899人</span>']
                ],
                oddRowBGC: 'rgba(21,66,116,0.15)',
                evenRowBGC: 'rgba(21,66,116,0.3)',
                rowNum: 2,
                columnWidth: [20],
                // index: true
            }
            
        }
    }
}
</script>
<style lang="scss" scoped>
    .people-list{
        display: flex;
        align-items: center;
        .people-list-left, .people-list-right{
            flex: 1;
           .people-list-title{
                height: 36px;
                line-height: 36px;
                padding-left: 20px;
                background: url('../../img/103-4title.png') no-repeat;
                background-size: 100% 100%;
                margin-bottom: 25px;
                font-size:18px;
                font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                font-weight:bold;
                color:rgba(184,212,230,1);
           }
           .scroll-list{
               .list-item-first{
                    display: inline-block;
                    width:6px;
                    height:6px;
                    background:rgba(184,212,230,1);
               }
           }
        }
        .people-list-right{
            margin-left: 25px;
        }
    }
</style>


