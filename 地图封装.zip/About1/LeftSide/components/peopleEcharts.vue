<template>
    <div class="people-echart">
        <div class="people-echart-title">
            24小时实时人口趋势图
        </div>
        <div class="people-echart-line" ref="people-echart-line"></div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            mychart:null,
            chartData:[
                {
                    time: '00:00',
                    people: 200
                },
                {
                    time: '01:00',
                    people: 300
                },
                {
                    time: '02:00',
                    people: 400
                },
                {
                    time: '03:00',
                    people: 500
                },
                {
                    time: '04:00',
                    people: 600
                },
                {
                    time: '05:00',
                    people: 700
                },
                {
                    time: '06:00',
                    people: 800
                },
                {
                    time: '07:00',
                    people: 900
                },
                {
                    time: '08:00',
                    people: 1000
                },
                {
                    time: '09:00',
                    people: 1100
                },
                {
                    time: '10:00',
                    people: 1200
                },
                {
                    time: '11:00',
                    people: 1300
                },
                {
                    time: '12:00',
                    people: 1400
                },
                {
                    time: '13:00',
                    people: 1600
                },
                {
                    time: '14:00',
                    people: 1700
                },
                {
                    time: '15:00',
                    people: 1800
                },
                {
                    time: '16:00',
                    people: 1990
                },
                {
                    time: '17:00',
                    people: 2000
                },
                {
                    time: '18:00',
                    people: 2100
                },
                {
                    time: '19:00',
                    people: 2400
                },
                {
                    time: '20:00',
                    people: 2500
                },
                {
                    time: '21:00',
                    people: 2600
                },
                {
                    time: '22:00',
                    people: 1200
                },
                {
                    time: '23:00',
                    people: 3200
                },
                {
                    time: '24:00',
                    people: 3000
                },
            ]
        }
    },
    mounted(){
        this.draw();
    },
    methods:{
        draw(){
            this.mychart = this.$echarts.init(this.$refs['people-echart-line']);
            let option = this.getOption();
            window.onresize = this.mychart.resize;
            this.mychart.setOption(option);
        },
        getOption(){
            let xdata = [], ydata=[];
            this.chartData.map(item => {
                xdata.push(item.time);
                ydata.push(item.people);
            })
            // console.log(xdata, ydata)
            let option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#57617B'
                        }
                    }
                },
                legend: {
                    icon: 'rect',
                    itemWidth: 14,
                    itemHeight: 5,
                    itemGap: 13,
                    data: ['南宁-曼芭', '桂林-曼芭', '南宁-甲米'],
                    right: '4%',
                    textStyle: {
                        fontSize: 12,
                        color: '#F1F1F3'
                    }
                },
                grid: {
                    left: 0,
                    right: 0,
                    top: '20%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [{
                    type: 'category',
                    boundaryGap: false,
                    axisLine: {
                        lineStyle: {
                            color: '#57617B'
                        }
                    },
                    data: xdata
                }],
                yAxis: [{
                    type: 'value',
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show:false
                    },
                    axisLabel: {
                        margin: 10,
                        textStyle: {
                            fontSize: 14
                        }
                    },
                    splitLine: {
                        show:false
                    }
                }],
                series: [{
                    // name: '南宁-曼芭',
                    type: 'line',
                    smooth: true,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    },
                    areaStyle: {
                        normal: {
                            color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                offset: 0,
                                color: 'rgba(1,213,255,1)'
                            }, {
                                offset: 0.8,
                                color: 'rgba(0,159,191,1)'
                            }], false),
                            shadowColor: 'rgba(0, 0, 0, 0.1)',
                            shadowBlur: 10
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: 'rgb(137,189,27)'
                        }
                    },
                    data: ydata
                } ]
            }
            
            return option
        }
    }
}
</script>
<style lang="scss" scoped>
    .people-echart{
        &-title{
            height: 36px;
            line-height: 36px;
            background: url('../../img/105title.png') no-repeat;
            background-size: 100% 100%;
            padding-left: 20px;
            font-size:18px;
            font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
            font-weight:bold;
            color:rgba(184,212,230,1);
        }
        &-line{
            height: 153px;
            width: 100%;
        }
    }

</style>


