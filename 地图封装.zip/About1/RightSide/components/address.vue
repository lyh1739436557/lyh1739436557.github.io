<template>
    <div class="address">
        <div class="address-top">
            <div class="home-total">
                <div>实有房屋</div>
                <div>23243<span>间</span></div>
            </div>
            <div class="home-classify">
                <div v-for="(item,index) in hotalDatas" :key="index" class="home-classify-item">
                    <div>
                        {{item.name}}<span>{{item.tatal}}<span>家</span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            hotalDatas: [
                {
                    name: '旅馆',
                    tatal: 358,
                },
                {
                    name: '网吧',
                    tatal: 767,
                },
                {
                    name: '社区',
                    tatal: 250,
                },
                {
                    name: '日租房',
                    tatal: 500,
                },
                {
                    name: '短租房',
                    tatal: 654,
                },
                {
                    name: '猫眼',
                    tatal: 19892,
                },
            ]
        }
    },
    mounted(){},
    methods:{}
}
</script>
<style lang="scss" scoped>
    .address{
        padding: 58px 21px 0;
        &-top{
            display: flex;
            align-items: center;
            .home-total{
                width: 151px;
                height: 90px;
                background: url('../../img/203title.png') no-repeat;
                background-size: 100% 100%;
                font-size:16px;
                padding: 15px 0 0 30px;
                box-sizing: border-box;
                div{
                    &:first-child{
                        font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                        font-weight:bold;
                        color:rgba(255,255,255,0.9);
                        margin-bottom: 13px;
                    }
                    &:last-child{
                        font-size:21px;
                        font-family:DINAlternate-Bold,DINAlternate;
                        font-weight:bold;
                        color:rgba(1,213,255,1);
                        span{
                            font-size:12px;
                            font-family:PingFangSC-Regular,PingFang SC;
                            font-weight:400;
                            color:rgba(255,255,255,0.7);
                            margin-left: 5px;
                        }
                    }
                }
            }
            .home-classify{
                flex: 1;
                &-item{
                    width: 160px;
                    height: 40px;
                    line-height: 40px;
                    background: url('../../img/402box.png') no-repeat;
                    background-size: 100% 100%;
                    margin-left: 13px;
                    float: left;
                    &:nth-child(4){
                        margin-top: 10px;
                    }
                    &:nth-child(5){
                        margin-top: 10px;
                    }
                    &:nth-child(6){
                        margin-top: 10px;
                    }
                    div{
                        display: flex;
                        justify-content: center;
                        font-size:16px;
                        font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                        font-weight:bold;
                        color:rgba(255,255,255,0.9);
                        span{
                            font-size:21px;
                            font-family:DINAlternate-Bold,DINAlternate;
                            font-weight:bold;
                            color:rgba(1,213,255,1);
                            margin: 0 5px;
                            span{
                                font-family:PingFangSC-Regular,PingFang SC;
                                font-weight:400;
                                color:rgba(255,255,255,0.7);
                                font-size: 12px;
                            }
                        }
                    }
                }
            }

        }
    }
</style>


