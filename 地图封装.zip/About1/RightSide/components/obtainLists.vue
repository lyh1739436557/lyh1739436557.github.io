<template>
    <div class="obtain-list">
        <div class="obtain-list-left">
            <div class="obtain-list-itme" v-for="item in listData.slice(0, 7)" :key="item.id">
                <div class="item-num">{{item.id}}</div>
                <div class="item-name">{{item.deparment}}</div>
                <div class="item-house">{{item.house}} 间</div>
                <div class="item-people">{{item.people}} 人</div>
            </div>
        </div>
        <div class="obtain-list-right">
            <div class="obtain-list-itme" v-for="item in listData.slice(7)" :key="item.id">
                <div class="item-num">{{item.id}}</div>
                <div class="item-name">{{item.deparment}}</div>
                <div class="item-house">{{item.house}} 间</div>
                <div class="item-people">{{item.people}} 人</div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            listData:[
                {
                    id: 1,
                    deparment: '瑞金二路派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 2,
                    deparment: '南京东路派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 3,
                    deparment: '淮海中路派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 4,
                    deparment: '小东门派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 5,
                    deparment: '五里桥派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 6,
                    deparment: '老西门派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 7,
                    deparment: '打浦桥派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 8,
                    deparment: '豫园派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 9,
                    deparment: '外滩派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 10,
                    deparment: '蝎门派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 11,
                    deparment: '人民广场派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 12,
                    deparment: '金陵东路派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 13,
                    deparment: '瑞金二路派出所',
                    house: 345,
                    people: 5456
                },
                {
                    id: 14,
                    deparment: '水上派出所',
                    house: 345,
                    people: 5456
                }
            ]
        }
    }
}
</script>
<style lang="scss" scoped>
    .obtain-list{
        display: flex;
        align-items: center;
        margin: 20px 0 0;
        &-left, &-right{
            flex: 1;
            .obtain-list-itme{
                display: flex;
                align-items: center;
                height: 36px;
                margin-top: 5px;
                font-size:12px;
                font-family:PingFangSC-Semibold,PingFang SC;
                font-weight:600;
                color:rgba(255,255,255,0.8);
                &:first-child{
                    margin-top: 0;
                }
                &:nth-child(even){
                    background:rgba(21,66,116,0.3);
                }
                .item-num{
                    height: 14px;
                    width: 14px;
                    opacity:0.3;
                    border:1px solid rgba(93,233,248,1);
                    font-size:12px;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(1,213,255,1);
                    text-align: center;
                    line-height: 16px;
                    margin-right: 17px;
                }
                .item-name{
                    // flex: 1;
                    width: 90px;
                }
                .item-house{
                    flex: 1;
                    margin-left: 33px;
                    font-weight:500;
                    color:rgba(93,233,248,1);
                }
                .item-people{
                    flex: 1;
                    font-family:PingFangSC-Medium,PingFang SC;
                    font-weight:500;
                    color:rgba(184,212,230,1);
                }
            }
        }
        &-right{
            margin-left: 36px;
        }
    }
</style>


