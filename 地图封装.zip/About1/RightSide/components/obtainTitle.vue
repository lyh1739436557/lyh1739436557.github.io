<template>
    <div class="obtain-title">
        <span class="obtain-title-ads">黄浦<span></span></span>
        <span class="obtain-office">实有单位<span class="office-num">5663<span>家</span></span></span>
        <span class="obtain-people">从业人员<span class="people-num">5663<span>人</span></span></span>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
    .obtain-title{
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: url('../../img/501box.png') no-repeat;
        background-size: 100% 100%;
        font-size:16px;
        font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
        font-weight:bold;
        color:rgba(255,255,255,0.9);
        &-ads{
            display: flex;
            align-items: center;
            span{
                width:1px;
                height:12px;
                background:rgba(182,214,233,1);
                margin: 0 35px 0 10px;
            }
        }
        .obtain-office{
            display: flex;
            align-items: center;
        }
        .office-num{
            font-size:21px;
            font-family:DINAlternate-Bold,DINAlternate;
            font-weight:bold;
            margin-left: 15px;
            color:rgba(93,233,248,1);
            span{
                font-size:12px;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(255,255,255,0.7);
                margin-left: 5px;
            }
        }
        .obtain-people{
            display: flex;
            align-items: center;
            margin-left: 44px;
            .people-num{
                font-size:21px;
                font-family:DINAlternate-Bold,DINAlternate;
                font-weight:bold;
                margin-left: 15px;
                color:rgba(93,233,248,1);
                span{
                    font-size:12px;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(255,255,255,0.7);
                    margin-left: 5px;
                }
            }
        }
    }
</style>

