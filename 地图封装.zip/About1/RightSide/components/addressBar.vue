<template>
    <div class="address-bar">
        <div class="address-bar-title">派出所落脚点分布</div>
        <tab-check v-on:tabCheck = "tabCheck"></tab-check>
        <div class="chart-bar" ref="chart-bar"></div>
    </div>
</template>
<script>
import tabCheck from './tabCheck';
export default {
    data(){
        return{
            chartData:[
                {
                    month: "南京东路",
                    value: 87,
                    ratio: 14.89
                },
                {
                    month: "外摊",
                    value: 70,
                    ratio: 79.49
                },

                {
                    month: "瑞金二路",
                    value: 15,
                    ratio: 75.8
                },

                {
                    month: "淮海中路",
                    value: 11,
                    ratio: 19.8
                },
                {
                    month: "豫园",
                    value: 11,
                    ratio: 44.5
                },
                {
                    month: "打浦桥",
                    value: 25,
                    ratio: 87.3
                },
                {
                    month: "老西门",
                    value: 27,
                    ratio: 87.3
                },
                {
                    month: "小东门",
                    value: 22,
                    ratio: 87.3
                },
                {
                    month: "五里桥",
                    value: 19,
                    ratio: 87.3
                },
                {
                    month: "半淞园",
                    value: 30,
                    ratio: 87.3
                },
                {
                    month: "人民广场",
                    value: 1,
                    ratio: 87.3
                },
                {
                    month: "新天地",
                    value: 2,
                    ratio: 87.3
                },
                {
                    month: "外滩治安",
                    value: 38,
                    ratio: 87.3
                },
                {
                    month: "南浦治安",
                    value: 0,
                    ratio: 87.3
                }
            ],
            myChart: null,
        }
    },
    components:{
        tabCheck
    },
    methods:{
        tabCheck(e){
            console.log(e, 'e')
        },
        drawEchart(){
            this.myChart = this.$echarts.init(this.$refs['chart-bar']);
            let option = this.getOption();
            window.onresize = this.myChart.resize;
            this.myChart.setOption(option)
        },
        getOption(){
            let xData = [], yData = [];
            let min = 100;
            this.chartData.map(item => {
                yData.push(item.month);
                if(item.value === 0) {
                    xData.push(item.value)
                } else {
                    xData.push(item.value)
                }
            });
            let option = {
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params) {
                        return "<span>" + params[0].name + "派出所  </span>" + "<span>" + params[0].value + "个</span>";
                    }
                },
                label: {
                    normal: {
                        textStyle: {
                            color: "#333"
                        }
                    },
                    emphasis: {
                        textStyle: {
                            color: "#333"
                        }
                    }
                },
                grid: {
                    left: 0,
                    right: 30,
                    bottom: '1%',
                    top: '30',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    axisLine: {
                        lineStyle: {
                            color: '#ffffff',
                            opacity: 0.72
                        }
                    },
                    axisTick: {
                        show: false,
                        interval: 0,
                        alignWithLabel: true
                    },
                    axisLabel: {
                        interval: 0,
                        rotate: '0',
                        textStyle: {
                            fontSize: 10,
                            color: '#ffffff',
                            opacity: 0.72
                        }
                    },
                    data: yData,
                    splitLine: {
                        show: false
                    }
                },
                yAxis: {
                    show:false
                },
                series: [{
                    name: '数量',
                    type: 'bar',
                    stack: '总量',
                    barWidth: 10,
                    label: {
                        normal: {
                            show: true,
                            // position: 'right',
                            textStyle: {
                                fontSize: 10,
                                color: '#ffffff'
                            }
                        }
                    },
                    itemStyle: {
                        normal: {
                            barBorderWidth: '0',
                            barMarginLeft: '6',
                            barBorderRadius: [10, 10, 0, 0],
                            barBorderColor: 'rgb(0,255,132)',
                            color: new this.$echarts.graphic.LinearGradient(0, 1, 0, 0, [{
                                offset: 0,
                                color: 'rgba(21,28,232,1)'
                            }, {
                                offset: 1,
                                color: 'rgba(36,242,255,1)'
                            }])
                        },
                        emphasis: {
                            barBorderWidth: '1',
                            barBorderColor: 'rgb(0,255,132)'
                            // color: 'rgba(26,177,98,.8)'
                        }
                    },
                    // 顺序 从下向上 传入
                    data: xData
                }]
            };
            return option;
        },
    },
    mounted(){
        this.drawEchart();
    }
}
</script>
<style lang="scss" scoped>
    .address-bar{
        padding: 0 21px;
        margin-top: 30px;
        &-title{
            height: 36px;
            background: url('../../img/311SubTitle.png') no-repeat;
            background-size: 100% 100%;
            line-height: 36px;
            padding-left: 20px;
            box-sizing: border-box;
        }
        .chart-bar{
            height: 220px;
        }
    }
</style>
