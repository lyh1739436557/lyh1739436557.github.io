<template>
    <div class="tab-check">
        <span v-for="item in tabLists" @click="tabCheck(item.id)" :key="item.id" :class=" selectId == item.id ? 'active' : ''">{{item.name}}</span>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tabLists:[
                {
                    id: 1,
                    name: '实有房屋'
                },
                {
                    id: 2,
                    name: '旅馆'
                },
                {
                    id: 3,
                    name: '网吧'
                },
                {
                    id: 4,
                    name: '社区'
                },
                {
                    id: 5,
                    name: '日租房'
                },
                {
                    id: 6,
                    name: '短租房'
                },
                {
                    id: 7,
                    name: '猫眼'
                }
            ],
            selectId: '1'
        }
    },
    methods:{
        tabCheck(e){
            this.selectId = e;
            this.$emit('tabCheck', e)
        }
    }
}
</script>
<style lang="scss" scoped>
    .tab-check{
        font-size:12px;
        font-family:PingFangSC-Regular,PingFang SC;
        font-weight:400;
        color:rgba(182,214,233,1);
        margin-top: 21px;
        span{
            padding: 0 10px;
            border-left: 1px solid #B6D6E9;
            box-sizing: border-box;
            cursor: pointer;
            &:first-child{
                border-left: 0;
            }
        }
        .active{
            color:rgba(93,233,248,1);
        }
    }
</style>


