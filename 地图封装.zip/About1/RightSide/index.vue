<template>
  <div class="person-right-side">
    <div class="person-right-address">
      <address-con></address-con>
      <address-bar></address-bar>
    </div>
    <div class="person-right-obtain">
      <obtain-title></obtain-title>
      <obtain-lists></obtain-lists>
    </div>
  </div>
</template>

<script>
import addressCon from './components/address';
import addressBar from './components/addressBar';
import obtainTitle from './components/obtainTitle';
import obtainLists from './components/obtainLists';
export default {
  components:{
    addressCon,
    addressBar,
    obtainTitle,
    obtainLists
  },
  data(){
    return{}
  },
}
</script>

<style lang="scss">
  .person-right-side{
    width: 713px;
    height: 100%;
    // background: pink;
    margin-left: 24px;
    .person-right-address{
      height: 512px;
      background: url('../img/400box.png') no-repeat;
      background-size: 100% 100%;
      margin-top: 10px;
    }
    .person-right-obtain{
      height: 422px;
      margin-top: 35px;
      background: url('../img/500box.png') no-repeat;
      background-size: 100% 100%;
      padding: 50px 26px 0;
      box-sizing: border-box;
    }
  }
</style>
