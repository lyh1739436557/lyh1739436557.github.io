<template>
    <div class="map-title">
        <div v-for="(item, index) in peopleData" :key="index" class="map-title-item">
            <div class="map-title-item-text">{{item.name}}</div>
            <div class="map-title-item-num">{{item.number}}</div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            peopleData:[
                {
                    name: '当前实有人口',
                    number: 1043175
                },
                {
                    name: '本区户籍人口',
                    number: 803610
                },
                {
                    name: '外区户籍人口',
                    number: 42379
                },
                {
                    name: '来沪人口',
                    number: 166377
                },
                {
                    name: '境外人口',
                    number: 30809
                },
            ]
        }
    }
}
</script>
<style lang="scss" scoped>
    .map-title{
        display: flex;
        align-items: center;
        justify-content: center;
        &-item{
            height: 110px;
            width: 350px;
            background: url('../../img/301lable.png') no-repeat;
            background-size: 100% 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-left: 15px;
            &:first-child{
                margin-left: 0;
            }
            &-text{
                font-size:20px;
                font-family:FZZCHJW--GB1-0,FZZCHJW--GB1;
                font-weight:normal;
                color:rgba(255,255,255,1);
                margin-top: 12px;
                margin-bottom: 4px;
            }
            &-num{
                font-size:42px;
                font-family:DINAlternate-Bold,DINAlternate;
                font-weight:bold;
                color:rgba(1,213,255,1);
            }
        }
    }
</style>


