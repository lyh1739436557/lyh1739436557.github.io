<template>
    <div class="collect">
        <div class="collect-title">
            <div class="title-item">
                <span class="item-title">派出所</span>
                <span class="item-num">17 <span class="item-depart">个</span></span>
            </div>
            <div class="title-item">
                <span class="item-title">居委会</span>
                <span class="item-num">17 <span class="item-depart">个</span></span>
            </div>
            <div class="title-item">
                <span class="item-title">协管人员</span>
                <span class="item-num">17 <span class="item-depart">个</span></span>
            </div>
        </div>
        <div class="collect-depart">
            <div class="collect-depart-title">派出所辖区人口分布</div>
            <div class="depart-echart" ref="depart-echart"></div>
        </div>
        <div class="collect-space"></div>
        <div class="collect-bottom">
            <div class="collect-bottom-chart">
                <div class="bottom-chart-title">派出所辖区人口采集</div>
                <div class="chart-bar" ref="chart-bar"></div>
            </div>
            <div class="collect-bottom-people">
                <div class="people-title">协管人员</div>
                <div class="people-list">
                    <div class="people-list-item" v-for="item in new Array(5)" :key="item">
                        <img class="item-img" src="" alt="">
                        <div class="item-describe">
                            <div>
                                <span>协管人：</span>
                                <span>张云云</span>
                            </div>
                            <div>
                                <span>采集量：</span>
                                <span>3232人</span>
                            </div>
                            <div>半淞园派出所</div>
                            <div>半淞园街道居委</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            myChart:null,
            mychartBar: null,
            myChartdata:[
                {

                }
            ],
            chartData:[
                {
                    month: "南京东路",
                    value: 290,
                    ratio: 14.89
                },
                {
                    month: "外摊",
                    value: 390,
                    ratio: 79.49
                },

                {
                    month: "瑞金二路",
                    value: 490,
                    ratio: 75.8
                },

                {
                    month: "淮海中路",
                    value: 590,
                    ratio: 19.8
                },
                {
                    month: "豫园",
                    value: 600,
                    ratio: 44.5
                },
                {
                    month: "打浦桥",
                    value: 660,
                    ratio: 87.3
                },
                {
                    month: "老西门",
                    value: 777,
                    ratio: 87.3
                },
                {
                    month: "小东门",
                    value: 888,
                    ratio: 87.3
                },
                {
                    month: "五里桥",
                    value: 900,
                    ratio: 87.3
                },
                {
                    month: "半淞园",
                    value: 998,
                    ratio: 87.3
                },
                {
                    month: "人民广场",
                    value: 1089,
                    ratio: 87.3
                },
                {
                    month: "新天地",
                    value: 1209,
                    ratio: 87.3
                },
                {
                    month: "外滩治安",
                    value: 1233,
                    ratio: 87.3
                },
                {
                    month: "南浦治安",
                    value: 1300,
                    ratio: 87.3
                }
            ],
        }
    },
    methods:{
        drawBar(){
            this.myChart = this.$echarts.init(this.$refs['depart-echart'])
            let option = this.getOption();
            window.onresize = this.myChart.resize;
            this.myChart.setOption(option);
        },
        getOption(){
            let option = {
                legend: {
                    data: ['户籍', '来沪', '境外'],
                    textStyle: {
                        color:'rgba(184,212,230,1)',
                        fontSize: 14
                    },
                    right: 0
                },
                grid:{
                    left:30,
                    right: 0,
                    bottom: 20
                },
                toolbox: {
                    show: false,
                    // feature: {
                    //     dataView: {show: true, readOnly: false},
                    //     magicType: {show: true, type: ['line', 'bar']},
                    //     restore: {show: true},
                    //     saveAsImage: {show: true}
                    // }
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                        axisTick:{
                            show:false
                        },
                        axisLabel:{
                            color:"rgba(255,255,255,0.5)",
                        },
                    }
                ],
                yAxis: {
                    type:'value',
                    nameTextStyle:{
                        color: '#fff'
                    },
                    axisLine:{
                        show:false
                    },
                    axisTick:{
                        show:false
                    },
                    axisLabel:{
                        color:"rgba(255,255,255,0.5)",
                    },
                    splitLine:{
                        lineStyle:{
                            width: 2,
                            color:'rgba(255,255,255,0.1)'
                        }
                    }
                },
                series: [
                    {
                        name: '户籍',
                        type: 'bar',
                        data: [2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3],
                        
                    },
                    {
                        name: '来沪',
                        type: 'bar',
                        data: [2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3],
                        
                    },
                    {
                        name: '境外',
                        type: 'bar',
                        data: [2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3],
                        
                    },
                ]
            };
            return option;
        },
        drawChartBar(){
            this.mychartBar = this.$echarts.init(this.$refs['chart-bar']);
            let option  = this.getChartOption();
            window.onresize = this.mychartBar.resize;
            this.mychartBar.setOption(option)
        },
        getChartOption(){
            let xData = [], yData = [];
            let min = 100;
            this.chartData.map(item => {
                yData.push(item.month);
                if(item.value === 0) {
                    xData.push(item.value + min)
                } else {
                    xData.push(item.value)
                }
            });
            let option = {
                tooltip: {
                    trigger: 'axis',
                    // textStyle: {
                    //     align: 'left',
                    //     color: '#5cc1ff',
                    //     // color: '#fff',
                    //     fontSize: '16'
                    // },
                    // backgroundColor: 'rgba(15, 52, 135, 0.5)',
                    // borderWidth: '1',
                    // borderColor: '#5cc1ff',
                    // extraCssText: 'box-shadow: 0 0 10px rgba(255, 255, 255, 0.7);',
                    formatter: function(params) {
                        return "<span>" + params[0].name + "派出所  </span>" + "<span>" + params[0].value + "h</span>";
                    }
                },
                label: {
                    normal: {
                        textStyle: {
                            color: "#333"
                        }
                    },
                    emphasis: {
                        textStyle: {
                            color: "#333"
                        }
                    }
                },
                grid: {
                    left: '1%',
                    right: '7%',
                    bottom: 0,
                    top: 0,
                    containLabel: true
                },
                yAxis: {
                    type: 'category',
                    axisLine: {
                        lineStyle: {
                            color: '#ffffff',
                            opacity: 0.72
                        }
                    },
                    axisTick: {
                        show: false,
                        interval: 0,
                        alignWithLabel: true
                    },
                    axisLabel: {
                        interval: 0,
                        rotate: '0',
                        textStyle: {
                            fontSize: 12,
                            color: '#ffffff',
                            opacity: 0.72
                        }
                    },
                    data: yData,
                    splitLine: {
                        show: false
                    }
                },
                xAxis: {
                    show:false
                },
                series: [{
                    name: '数量',
                    type: 'bar',
                    stack: '总量',
                    barWidth: 6,
                    label: {
                        normal: {
                            show: true,
                            position: 'right',
                            textStyle: {
                                fontSize: 10,
                                color: '#ffffff'
                            }
                        }
                    },
                    itemStyle: {
                        normal: {
                            barBorderWidth: '0',
                            barMarginLeft: '6',
                            barBorderRadius: [0, 10, 10, 0],
                            barBorderColor: 'rgb(0,255,132)',
                            color: new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                                offset: 0,
                                color: 'rgba(21,28,232,1)'
                            }, {
                                offset: 1,
                                color: 'rgba(36,242,255,1)'
                            }])
                        },
                        emphasis: {
                            barBorderWidth: '1',
                            barBorderColor: 'rgb(0,255,132)'
                            // color: 'rgba(26,177,98,.8)'
                        }
                    },
                    // 顺序 从下向上 传入
                    data: xData
                }]
            };
            return option;
        }
    },
    mounted(){
        this.drawBar();
        this.drawChartBar();
    },
    beforeDestroy() {
        !!this.myChart && this.myChart.dispose();
        !!this.mychartBar && this.mychartBar.dispose();
    }

}
</script>
<style lang="scss" scoped>
    .collect{
        position: absolute;
        top: 0;
        left: 100px;
        width: 715px;
        height: 677px;
        background: url('../../img/310Inbox.png') no-repeat;
        background-size: 100% 100%;
        padding: 0 21px;
        &-title{
            margin-top: 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            .title-item{
                height: 40px;
                width: 214px;
                text-align: center;
                line-height: 40px;
                background: url('../../img/311box.png') no-repeat;
                background-size: 100% 100%;
                font-size:16px;
                font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                font-weight:bold;
                color:rgba(255,255,255,0.9);
                .item-num{
                    font-size:21px;
                    font-family:DINAlternate-Bold,DINAlternate;
                    font-weight:bold;
                    color:rgba(1,213,255,1);
                    margin-left: 15px;
                    .item-depart{
                        font-size:12px;
                        font-family:PingFangSC-Regular,PingFang SC;
                        font-weight:400;
                        color:rgba(255,255,255,0.7);
                        margin-left: 5px;
                    }
                }
            }
        }
        &-depart{
            &-title{
                margin-top: 23px;
                height: 36px;
                line-height: 36px;
                padding-left: 20px;
                font-size:18px;
                font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                font-weight:bold;
                color:rgba(184,212,230,1);
                background: url('../../img/311SubTitle.png') no-repeat;
                background-size: 100% 100%;
            }
            .depart-echart{
                height: 231px;
            }
        }
        &-space{
            height: 2px;
            background:rgba(157,221,253,1);
            opacity:0.06;
            margin-top: 20px;
        }
        &-bottom{
            margin-top: 14px;
            display: flex;
            &-chart{
                width: 369px;
                .bottom-chart-title{
                    height: 36px;
                    padding-left: 20px;
                    background: url('../../img/312SubTitle.png') no-repeat;
                    background-size: 100% 100%;
                    line-height: 36px;
                    font-size:18px;
                    font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                    font-weight:bold;
                    color:rgba(184,212,230,1);
                }
                .chart-bar{
                    height: 200px;
                    margin-top: 10px;
                }
            }
            &-people{
                flex: 1;
                margin-left: 29px;
                .people-title{
                    font-size:18px;
                    font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;
                    font-weight:bold;
                    color:rgba(184,212,230,1);
                    height: 36px;
                    padding-left: 20px;
                    background: url('../../img/313SubTitle.png') no-repeat;
                    background-size: 100% 100%;
                    line-height: 36px;
                }
                .people-list{
                    height: 220px;
                    overflow: auto;
                    &-item{
                        display: flex;
                        // align-items: center;
                        margin-top: 10px;
                        &:first-child{
                            margin-top: 14px;
                        }
                        .item-img{
                            width:71px;
                            height:93px;
                            background:rgba(16,193,255,1);
                        }
                        .item-describe{
                            flex: 1;
                            margin-left: 17px;
                            font-size:12px;
                            font-family:PingFangSC-Semibold,PingFang SC;
                            font-weight:600;
                            color:rgba(255,255,255,0.8);
                            div{
                                height: 20px;
                                line-height: 20px;
                                padding-left: 16px;
                                margin-bottom: 5px;
                                background:rgba(21,66,116,0.15);
                                &:nth-child(2){
                                    span:nth-child(2){
                                        color:rgba(93,233,248,1);
                                    }
                                }
                                &:last-child{
                                    margin-bottom: 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
</style>
