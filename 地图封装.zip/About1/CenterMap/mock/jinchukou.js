let data = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "name": "东侧与浦东交界",
        "Juncture_direction": "limgrct"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          121.50458335876463,
          31.22271082561441
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "南侧与浦东交界",
        "Juncture_direction": "uimgdct"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          121.48012161254883,
          31.19048322901983
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "西侧与徐汇交界",
        "Juncture_direction": "lctrimg"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          121.4622688293457,
          31.202891052495104
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "西侧与静安交界",
        "Juncture_direction": "lctrimg"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          121.45591735839842,
          31.22227043134722
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "北侧与虹口交界",
        "Juncture_direction": "uctdimg"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          121.47754669189452,
          31.24127891628173
        ]
      }
    }
  ]
}

export default data
