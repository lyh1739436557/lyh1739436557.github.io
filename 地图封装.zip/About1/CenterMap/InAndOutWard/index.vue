<template>
  <div>
    <area-layer :areaData="yuyuanAreaData | lineAndAreaData" :config="zdqyconfig" ref="zdqy1_layer"></area-layer>
    <area-layer :areaData="xiaoquAreaData | lineAndAreaData" :config="xqconfig" ref="xq1_layer"></area-layer>
    <area-layer :areaData="louyuAreaData | lineAndAreaData" :config="lyconfig" ref="ly_layer"></area-layer>
    <html-layer :pointerData="jinchukouAreaData | htmlData" :config="jckconfig" ref="jck_layer"></html-layer>
  </div>
</template>

<script>
import yuyuanAreaData from "../mock/yuyuan";
import xiaoquAreaData from "../mock/xiaoqu";
import louyuAreaData from "../mock/louyu";
import jinchukouAreaData from "../mock/jinchukou";
import zdqyconfig from "../mapconfig/crk_zdqy_config";
import lyconfig from "../mapconfig/crk_ly_config";
import xqconfig from "../mapconfig/crk_xq_config";
import jckconfig from "../mapconfig/crk_jck_config";
import AreaLayer from "../maptalks/areaLayer/index";
import HtmlLayer from "../maptalks/htmlLayer/index";
export default {
  props: {
    flowBtnData: {
      type: Array
    }
  },
  data() {
    return {
      zdqyconfig,
      lyconfig,
      xqconfig,
      jckconfig,
      jinchukouAreaData,
      yuyuanAreaData,
      xiaoquAreaData,
      louyuAreaData
    };
  },
  methods: {
    initLayer(map) {
      this.$refs["zdqy1_layer"].initLayer(map).hide();
      this.$refs["xq1_layer"].initLayer(map).hide();
      this.$refs["ly_layer"].initLayer(map).hide();
      this.$refs["jck_layer"].initLayer(map).hide();
    },
    openLayer() {
      this.flowBtnData.map(item => {
        this.$refs[item.layerRefs].showOrCloseLayer(item.visible);
      });
    },
    showOrCloseLayer(ref, bool) {
      this.$refs[ref].showOrCloseLayer(bool);
    },
    closeAllLayer() {
      this.$refs["zdqy1_layer"].showOrCloseLayer(false);
      this.$refs["xq1_layer"].showOrCloseLayer(false);
      this.$refs["ly_layer"].showOrCloseLayer(false);
      this.$refs["jck_layer"].showOrCloseLayer(false);
    }
  },
  components: {
    AreaLayer,
    HtmlLayer
  },
  filters: {
    lineAndAreaData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          data: val.geometry.coordinates[0],
          name: val.properties.name,
          openDialog: {
            title: val.properties.name
          }
        });
        return prev;
      }, arr);
      return result;
    },
    htmlData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          latLng: val.geometry.coordinates,
          name: {
            name: val.properties.name,
            inPerson: 8382,
            outPerson: 1320,
            JunctureDirection: val.properties.Juncture_direction
          },
          openDialog: {
            coming: 808,
            back: 909
          }
        });
        return prev;
      }, arr);
      return result;
    }
  }
};
</script>
