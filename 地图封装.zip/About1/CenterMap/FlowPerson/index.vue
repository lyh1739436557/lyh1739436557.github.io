<template>
  <div>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="zdqyconfig"
      ref="zdqy_layer"
    ></pointer-layer>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="xqconfig"
      ref="xq_layer"
    ></pointer-layer>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="swlyconfig"
      ref="swly_layer"
    ></pointer-layer>
  </div>
</template>

<script>
import lineAndAreaData from "../mock/area";
import zdqyconfig from "../mapconfig/ldz_zdqy_config";
import xqconfig from "../mapconfig/ldz_xq_config";
import swlyconfig from "../mapconfig/ldz_swly_config";
import PointerLayer from "../maptalks/pointerLayer/index";
export default {
  props: {
    flowBtnData: {
      type: Array
    }
  },
  data() {
    return {
      zdqyconfig,
      xqconfig,
      swlyconfig,
      lineAndAreaData
    };
  },
  methods: {
    initLayer(map) {
      this.$refs['zdqy_layer'].initLayer(map).hide();
      this.$refs['xq_layer'].initLayer(map).hide();
      this.$refs['swly_layer'].initLayer(map).hide();
    },
    openLayer() {
      this.flowBtnData.map(item => {
        this.$refs[item.layerRefs].showOrCloseLayer(item.visible);
      })
    },
    showOrCloseLayer(ref, bool) {
      this.$refs[ref].showOrCloseLayer(bool);
    },
    closeAllLayer() {
      this.$refs['zdqy_layer'].showOrCloseLayer(false);
      this.$refs['xq_layer'].showOrCloseLayer(false);
      this.$refs['swly_layer'].showOrCloseLayer(false);
    }
  },
  components: {
    PointerLayer
  },
  filters: {
    pointerData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          latLng: val.properties.cp,
          name: val.properties.name,
          openDialog: {
            coming: 808,
            back: 909
          }
        });
        return prev;
      }, arr);
      return result;
    }
  }
};
</script>
