<template>
  <div class="map-container">
    <div class="person-center-map-select">
      <div
        v-for="item in navData"
        :key="item.id"
        class="person-center-map-select-item"
        :class="item.visible ? 'person-center-map-select-active' : ''"
        @click="changeLayer(item.id)"
      >
        <span>{{ item.name }}</span>
      </div>
    </div>
    <div class="person-center-layer-select" v-show="childrenNavData != undefined">
      <div
        v-for="item in childrenNavData"
        :key="item.id"
        class="person-center-layer-select-item"
        :class="item.visible ? 'person-center-layer-select-active' : ''"
        @click="changeChildLayer(item.id)"
      >
        <span>{{ item.name }}</span>
      </div>
    </div>
    <div class="person-center-layer-chart" v-if="chartDialogIsShow">
      <people-collect></people-collect>
    </div>
    <div id="person-center-map">
      <case-map
        :target="mapconfig.target"
        :view="mapconfig.options"
        :layer="mapconfig.baseLayer"
        v-on:succeedCreateMap="initMap"
      >
        <pointer-layer
          :pointerData="lineAndAreaData | pointerData"
          :config="rkgkconfig"
          ref="rkgk_layer"
        ></pointer-layer>
        <pointer-layer
          :pointerData="lineAndAreaData | pointerData"
          :config="jycconfig"
          ref="jyc_layer"
        ></pointer-layer>
        <inout-ward :flowBtnData="navData[1].children" ref="crk_layer"></inout-ward>
        <flow-person :flowBtnData="navData[2].children" ref="ldz_layer"></flow-person>
        <foot-hold :flowBtnData="navData[3].children" ref="ljd_layer"></foot-hold>
        <area-layer
          :areaData="lineAndAreaData | lineAndAreaData"
          :config="areaconfig"
          ref="area_layer"
        ></area-layer>
        <linestring-layer
          :areaData="lineAndAreaData | lineData"
          :config="linestringconfig"
          ref="line_layer"
        ></linestring-layer>
        <text-layer
          :pointerData="lineAndAreaData | pointerData"
          :config="textconfig"
          ref="text_layer"
        ></text-layer>
      </case-map>
    </div>
    <div class="person-center-layer-title" v-if="titleDialogIsShow">
      <people-title-modal></people-title-modal>
    </div>
  </div>
</template>

<script>
import { TileLayer } from "maptalks";
import mapconfig from "./mapconfig/map_config";
import CaseMap from "./maptalks/map/index";
import lineAndAreaData from "./mock/area";
import linestringconfig from "./mapconfig/3Dline_layer_config";
import LinestringLayer from "./maptalks/3DlineLayer/index";
import areaconfig from "./mapconfig/area_layer_config";
import AreaLayer from "./maptalks/areaLayer/index";
import rkgkconfig from "./mapconfig/rkgk_config";
import jycconfig from "./mapconfig/jyc_config";
import PointerLayer from "./maptalks/pointerLayer/index";
import textconfig from "./mapconfig/text_layer_config";
import TextLayer from "./maptalks/textLayer/index";
import FlowPerson from "./FlowPerson/index"; //流动中图层
import FootHold from "./FootHold/index"; //落脚点图层
import InoutWard from "./InAndOutWard/index"; //出入口图层
import PeopleCollect from './components/peopleCollect';
import PeopleTitleModal from './components/peopleTitleModal';
export default {
  data() {
    return {
      mapconfig,
      rkgkconfig,
      jycconfig,
      linestringconfig,
      areaconfig,
      lineAndAreaData,
      textconfig,
      allLayer: {},
      navData: [
        {
          id: 0,
          name: "人口概况",
          layerRefs: "rkgk_layer",
          openTextLayer: true,
          visible: true
        },
        {
          id: 1,
          name: "出入口",
          layerRefs: "crk_layer",
          visible: false,
          closeLineLayer: true,
          children: [
            {
              id: 0,
              name: "重点区域",
              layerRefs: "zdqy1_layer",
              visible: true
            },
            {
              id: 1,
              name: "小区",
              layerRefs: "xq1_layer",
              visible: true
            },
            {
              id: 2,
              name: "楼宇",
              layerRefs: "ly_layer",
              visible: true
            },
            {
              id: 3,
              name: "进出口",
              layerRefs: "jck_layer",
              visible: true
            }
          ]
        },
        {
          id: 2,
          name: "流动中",
          layerRefs: "ldz_layer",
          visible: false,
          children: [
            {
              id: 0,
              name: "重点区域",
              layerRefs: "zdqy_layer",
              visible: true
            },
            {
              id: 1,
              name: "小区",
              layerRefs: "xq_layer",
              visible: false
            },
            {
              id: 2,
              name: "商务楼宇",
              layerRefs: "swly_layer",
              visible: false
            }
          ]
        },
        {
          id: 3,
          name: "落脚点",
          layerRefs: "ljd_layer",
          visible: false,
          children: [
            {
              id: 0,
              name: "旅馆",
              layerRefs: "lg_layer",
              visible: true
            },
            {
              id: 1,
              name: "社区",
              layerRefs: "sq_layer",
              visible: false
            },
            {
              id: 2,
              name: "日租房",
              layerRefs: "rzf_layer",
              visible: false
            },
            {
              id: 3,
              name: "短租房",
              layerRefs: "dzf_layer",
              visible: false
            }
          ]
        },
        {
          id: 4,
          name: "就业处",
          layerRefs: "jyc_layer",
          openTextLayer: true,
          visible: false
        },
        {
          id: 5,
          name: "人口采集",
          layerRefs: "rkcj_layer",
          visible: false
        }
      ],
      oldOpenLayerId: 0, //因为是单选框，所以只需要存储上次的图层序号即可
      changeLayerId: 0, //将要改变的图层ID
      childrenNavData: [],
      textLayerIsShow: true,
      chartDialogIsShow: false,
      titleDialogIsShow: true,
    };
  },
  components: {
    CaseMap,
    PointerLayer,
    AreaLayer,
    LinestringLayer,
    TextLayer,
    PeopleCollect,
    FlowPerson,
    FootHold,
    InoutWard,
    PeopleTitleModal
  },
  filters: {
    lineData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push(val.geometry.coordinates[0]);
        return prev;
      }, arr);
      return result;
    },
    lineAndAreaData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          data: val.geometry.coordinates[0],
          name: val.properties.name,
          openDialog: {
            title: "是一个区域"
          }
        });
        return prev;
      }, arr);
      return result;
    },
    pointerData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          latLng: val.properties.cp,
          name: val.properties.name,
          openDialog: {
            coming: 808,
            back: 909
          }
        });
        return prev;
      }, arr);
      return result;
    }
  },
  methods: {
    initMap(e) {
      this.$refs["area_layer"].initLayer(e);
      this.$refs["line_layer"].initLayer(e);
      this.$refs["text_layer"].initLayer(e);
      this.initAllLayer(e);
    },
    initAllLayer(map) {
      this.navData.map(item => {
        if (!!this.$refs[item.layerRefs]) {
          if (!!item.children && item.children.length !== 0) {
            this.$refs[item.layerRefs].initLayer(map);
          } else {
            item.visible
              ? this.$refs[item.layerRefs].initLayer(map).show()
              : this.$refs[item.layerRefs].initLayer(map).hide();
          }
        }
      });
    },
    changeBtn(e) {
      this.navData[this.oldOpenLayerId].visible = !this.navData[
        this.oldOpenLayerId
      ].visible;
      this.navData[e].visible = !this.navData[e].visible;
    },
    openOrCloseTextLayer(bool) {
      bool
        ? this.$refs["text_layer"].showOrCloseLayer(true)
        : this.$refs["text_layer"].showOrCloseLayer(false);
    },
    openOrCloseLineLayer(bool) {
      bool
        ? this.$refs["line_layer"].showOrCloseLayer(false)
        : this.$refs["line_layer"].showOrCloseLayer(true);
    },
    openOrcloseChartDialog(bool) {
      this.chartDialogIsShow = bool;
    },
    showOrHideLayer(target, bool) {
      if (this.$refs[target.layerRefs]) {
        if (!!target.children && target.children.length !== 0) {
          bool
            ? this.$refs[target.layerRefs].openLayer()
            : this.$refs[target.layerRefs].closeAllLayer();
        } else {
          this.$refs[target.layerRefs].showOrCloseLayer(bool);
        }
      }
    },
    // 修改childrennavdata
    changeChildrenLayerNavData(e) {
      this.childrenNavData = this.navData[e].children;
    },
    changeLayer(e) {
      if (e === this.oldOpenLayerId) return;
      this.showOrHideLayer(
        this.navData[this.oldOpenLayerId],
        !this.navData[this.oldOpenLayerId].visible
      );
      this.openOrCloseTextLayer(this.navData[e].openTextLayer);
      this.openOrCloseLineLayer(this.navData[e].closeLineLayer);
      this.openOrcloseChartDialog(e === 5);
      this.changeBtn(e);
      this.changeChildrenLayerNavData(e);
      this.showOrHideLayer(this.navData[e], this.navData[e].visible);
      this.oldOpenLayerId = e;
    },
    changeChildLayer(e) {
      this.changeChildBtn(e);
      this.showOrHideChildLayer(e);
    },
    changeChildBtn(id) {
      this.childrenNavData[id].visible = !this.childrenNavData[id].visible;
    },
    showOrHideChildLayer(id) {
      this.$refs[this.navData[this.oldOpenLayerId].layerRefs].showOrCloseLayer(
        this.childrenNavData[id].layerRefs,
        this.childrenNavData[id].visible
      );
    }
  }
};
</script>

<style lang="scss" scope>
.map-container {
  height: 939px;
  width: 1883px;
  margin-top: 28px;
  position: relative;
  #person-center-map {
    height: 100%;
    width: 1883px;
    .in_out_layer-limgrct {
      width: 220px;
      height: 120px;
      &-img {
        width: 120px;
        height: 30px;
        background: url("../img/img_arrow1.png") no-repeat center/(100% 100%);
      }
      &-container {
        width: 120px;
        margin-left: 100px;
        div {
          width: 120px;
          height: 31px;
          background: linear-gradient(
            90deg,
            rgba(3, 12, 41, 0.7) 0%,
            rgba(5, 13, 47, 0.41) 100%
          );
          line-height: 31px;
          padding-left: 10px;
        }
        div:nth-child(1) {
          background: url("../img/img_path2.png") no-repeat center/(100% 100%);
        }
        div:nth-child(2) {
          color: #5DE9F8;
        }
        div:nth-child(3) {
          color: #8CAFFF;
        }
      }
    }
    .in_out_layer-lctrimg {
      width: 220px;
      height: 120px;
      &-img {
        width: 120px;
        height: 30px;
        margin-left: 100px;
        background: url("../img/img_arrow1.png") no-repeat center/(100% 100%);
      }
      &-container {
        width: 120px;
        div {
          width: 120px;
          height: 31px;
          background: linear-gradient(
            90deg,
            rgba(3, 12, 41, 0.7) 0%,
            rgba(5, 13, 47, 0.41) 100%
          );
          line-height: 31px;
          padding-left: 10px;
        }
        div:nth-child(1) {
          background: url("../img/img_path2.png") no-repeat center/(100% 100%);
        }
        div:nth-child(2) {
          color: #5DE9F8;
        }
        div:nth-child(3) {
          color: #8CAFFF;
        }
      }
    }
    .in_out_layer-uctdimg {
      width: 120px;
      height: 220px;
      &-img {
        width: 30px;
        height: 120px;
        margin-left: 80px;
        background: url("../img/img_arrow2.png") no-repeat center/(100% 100%);
      }
      &-container {
        width: 120px;
        div {
          width: 120px;
          height: 31px;
          background: linear-gradient(
            90deg,
            rgba(3, 12, 41, 0.7) 0%,
            rgba(5, 13, 47, 0.41) 100%
          );
          line-height: 31px;
          padding-left: 10px;
        }
        div:nth-child(1) {
          background: url("../img/img_path2.png") no-repeat center/(100% 100%);
        }
        div:nth-child(2) {
          color: #5DE9F8;
        }
        div:nth-child(3) {
          color: #8CAFFF;
        }
      }
    }
    .in_out_layer-uimgdct {
      width: 130px;
      height: 220px;
      &-img {
        width: 30px;
        height: 120px;
        margin-left: 80px;
        background: url("../img/img_arrow2.png") no-repeat center/(100% 100%);
      }
      &-container {
        width: 120px;
        div {
          width: 120px;
          height: 31px;
          background: linear-gradient(
            90deg,
            rgba(3, 12, 41, 0.7) 0%,
            rgba(5, 13, 47, 0.41) 100%
          );
          line-height: 31px;
          padding-left: 10px;
        }
        div:nth-child(1) {
          background: url("../img/img_path2.png") no-repeat center/(100% 100%);
        }
        div:nth-child(2) {
          color: #5DE9F8;
        }
        div:nth-child(3) {
          color: #8CAFFF;
        }
      }
    }
    .maptalks-msgBox {
      background: rgba(3, 18, 58, 0.3);
      border: none;
      color: white;
      min-height: 100px;
      .maptalks-msgContent {
        display: flex;
        flex-flow: column nowrap;
        min-width: 100px;
        .ljd_opendialog {
          width: 100%;
          height: 120px;
          font-size: 16px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          line-height: 22px;
          letter-spacing: 1px;
          background: url("../img/img_popup2.png") no-repeat center/(100% 100%);
          display: flex;
          flex-flow: row nowrap;
          justify-content: space-around;
          align-items: center;
          div:nth-child(2) {
            height: 70px;
            width: 70px;
            background: url("../img/img_qr1.png") no-repeat center/(100% 100%);
            img {
              margin: 5px;
              height: 60px;
              width: 60px;
            }
          }
          div:nth-child(1) {
            display: flex;
            flex-flow: column nowrap;
            justify-content: center;
            align-items: center;
            span:nth-child(1) {
              width: 151px;
              height: 24px;
              color: rgba(13, 42, 51, 1);
              background: rgba(115, 230, 191, 1);
            }
            span:nth-child(2) {
              width: 151px;
              height: 24px;
              color: #73e6bf;
            }
            span:nth-child(3) {
              width: 151px;
              height: 24px;
              color: #73e6bf;
            }
            span:nth-child(4) {
              width: 151px;
              height: 24px;
              color: #73e6bf;
            }
          }
        }
        .ljd_opendialog_lg {
          background: url("../img/img_popup1.png") no-repeat center/(100% 100%);
          div:nth-child(1) {
            span:nth-child(1) {
              background: #01d5ff;
            }
            span:nth-child(2) {
              color: #01d5ff;
            }
            span:nth-child(3) {
              color: #01d5ff;
            }
            span:nth-child(4) {
              color: #01d5ff;
            }
          }
        }
        .ljd_opendialog_dzf {
          background: url("../img/img_popup4.png") no-repeat center/(100% 100%);
          div:nth-child(1) {
            span:nth-child(1) {
              background: #98f5f8;
            }
            span:nth-child(2) {
              color: #98f5f8;
            }
            span:nth-child(3) {
              color: #98f5f8;
            }
            span:nth-child(4) {
              color: #98f5f8;
            }
          }
        }
        .ljd_opendialog_rzf {
          background: url("../img/img_popup3.png") no-repeat center/(100% 100%);
          div:nth-child(1) {
            span:nth-child(1) {
              background: #ffe095;
            }
            span:nth-child(2) {
              color: #ffe095;
            }
            span:nth-child(3) {
              color: #ffe095;
            }
            span:nth-child(4) {
              color: #ffe095;
            }
          }
        }
        .opendialogcoming {
          width: 100px;
          height: 25px;
          font-size: 21px;
          font-family: DINAlternate-Bold, DINAlternate;
          font-weight: bold;
          color: rgba(93, 233, 248, 1);
          line-height: 25px;
        }
        .opendialogback {
          width: 100px;
          height: 25px;
          font-size: 21px;
          font-family: DINAlternate-Bold, DINAlternate;
          font-weight: bold;
          color: rgba(140, 175, 255, 1);
          line-height: 25px;
        }
        .opendialogcoming1 {
          width: 200px;
          height: 25px;
          font-size: 21px;
          font-family: DINAlternate-Bold, DINAlternate;
          font-weight: bold;
          color: rgba(93, 233, 248, 1);
          line-height: 25px;
        }
        .opendialogback1 {
          width: 200px;
          height: 25px;
          font-size: 21px;
          font-family: DINAlternate-Bold, DINAlternate;
          font-weight: bold;
          color: rgba(140, 175, 255, 1);
          line-height: 25px;
        }
        div {
          margin-top: 4px;
          margin-left: 5px;
        }
      }
      .maptalks-ico {
        width: 0;
        height: 0;
        border-left: 8.5px solid transparent;
        border-right: 8.5px solid transparent;
        border-top: 10px solid rgba(3, 18, 58, 0.8);
        background: none;
      }
    }
  }
  .person-center-map-select {
    position: absolute;
    bottom: 38px;
    right: 38px;
    width: 130px;
    height: 250px;
    display: flex;
    flex-flow: column nowrap;
    justify-content: space-around;
    align-items: center;
    background: rgba(3, 18, 58, 1);
    opacity: 0.72;
    z-index: 10;
    &-item:hover {
      background: url("../img/304menu_actived.png");
    }
    &-item {
      width: 130px;
      height: 33px;
      background: url("../img/304menu .png");
      cursor: pointer;
      display: flex;
      justify-content: center;
      span {
        width: 130px;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: rgba(255, 255, 255, 1);
        text-align: center;
        line-height: 33px;
      }
    }
    &-active {
      background: url("../img/304menu_actived.png");
    }
  }
  .person-center-layer-select {
    position: absolute;
    bottom: 38px;
    left: 38px;
    height: 30px;
    background: rgba(7, 20, 65, 0.9);
    border: 2px solid rgba(115, 172, 230, 0.16);
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-around;
    align-items: center;
    z-index: 10;
    &-item:hover {
      border: 1px solid;
      border-image: linear-gradient(
          360deg,
          rgba(91, 131, 250, 1),
          rgba(2, 204, 253, 1)
        )
        1 1;
      background: linear-gradient(
        360deg,
        rgba(91, 131, 250, 1) 0%,
        rgba(2, 204, 253, 1) 100%
      );
    }
    &-item {
      width: 120px;
      height: 32px;
      border: 1px solid;
      border-image: linear-gradient(
          360deg,
          rgb(20, 47, 120) 0%,
          rgb(4, 158, 196) 100%
        )
        1 1;
      background: linear-gradient(
        360deg,
        rgb(20, 47, 120) 0%,
        rgb(4, 158, 196) 100%
      );
      opacity: 0.83;
      display: flex;
      flex-flow: column nowrap;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      span {
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: rgba(255, 255, 255, 1);
        line-height: 22px;
      }
    }
    div + div {
      margin-left: 5px;
    }
    &-active {
      border: 1px solid;
      border-image: linear-gradient(
          360deg,
          rgba(91, 131, 250, 1),
          rgba(2, 204, 253, 1)
        )
        1 1;
      background: linear-gradient(
        360deg,
        rgba(91, 131, 250, 1) 0%,
        rgba(2, 204, 253, 1) 100%
      );
    }
  }
  .person-center-layer-chart {
    position: absolute;
    top: 200px;
    left: 572px;
    z-index: 10;
  }
  .person-center-layer-title {
    position: absolute;
    top: 20px;
    width: 100%;
    z-index: 11;
  }
}
</style>
