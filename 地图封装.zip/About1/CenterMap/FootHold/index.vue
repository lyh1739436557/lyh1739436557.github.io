<template>
  <div>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="lgconfig"
      ref="lg_layer"
    ></pointer-layer>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="sqconfig"
      ref="sq_layer"
    ></pointer-layer>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="rzfconfig"
      ref="rzf_layer"
    ></pointer-layer>
    <pointer-layer
      :pointerData="lineAndAreaData | pointerData"
      :config="dzfconfig"
      ref="dzf_layer"
    ></pointer-layer>
  </div>
</template>

<script>
import lineAndAreaData from "../mock/area";
import lgconfig from "../mapconfig/ljd_lg_config";
import sqconfig from "../mapconfig/ljd_sq_config";
import rzfconfig from "../mapconfig/ljd_rzf_config";
import dzfconfig from "../mapconfig/ljd_dzf_config";
import PointerLayer from "../maptalks/pointerLayer/index";
export default {
  props: {
    flowBtnData: {
      type: Array
    }
  },
  data() {
    return {
      lgconfig,
      sqconfig,
      rzfconfig,
      dzfconfig,
      lineAndAreaData
    };
  },
  methods: {
    initLayer(map) {
      this.$refs['lg_layer'].initLayer(map).hide();
      this.$refs['sq_layer'].initLayer(map).hide();
      this.$refs['rzf_layer'].initLayer(map).hide();
      this.$refs['dzf_layer'].initLayer(map).hide();
    },
    openLayer() {
      this.flowBtnData.map(item => {
        this.$refs[item.layerRefs].showOrCloseLayer(item.visible);
      })
    },
    showOrCloseLayer(ref, bool) {
      this.$refs[ref].showOrCloseLayer(bool);
    },
    closeAllLayer() {
      this.$refs['lg_layer'].showOrCloseLayer(false);
      this.$refs['sq_layer'].showOrCloseLayer(false);
      this.$refs['rzf_layer'].showOrCloseLayer(false);
      this.$refs['dzf_layer'].showOrCloseLayer(false);
    }
  },
  components: {
    PointerLayer
  },
  filters: {
    pointerData: res => {
      let arr = [];
      let result = res.features.reduce((prev, val) => {
        prev.push({
          latLng: val.properties.cp,
          name: val.properties.name,
          openDialog: {
            coming: 808,
            back: 909
          }
        });
        return prev;
      }, arr);
      return result;
    }
  }
};
</script>
