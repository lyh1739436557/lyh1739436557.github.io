<template>
  <div></div>
</template>

<script>
import { VectorLayer, Polygon } from "maptalks";
export default {
  props: {
    areaData: {
      type: Array,
      required: true
    },
    config: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      layer: null
    };
  },
  watch: {
    areaData: {
      handler() {
        this.updateAllMultiPolygon();
      },
      deep: true
    }
  },
  methods: {
    initLayer(map) {
      this.layer = new VectorLayer(this.config.layerId).addTo(map);
      this.initMultiPolygon();
      return this.layer;
    },
    updateAllMultiPolygon() {
      this.layer.clear();
      this.initMultiPolygon();
    },
    showOrCloseLayer(bool) {
      if (bool) {
        this.layer.show();
      } else {
        this.layer.hide();
      }
    },
    // 多个区域的数据格式[[[[经纬度], [经纬度]]], [[[经纬度], [经纬度]]]]
    initMultiPolygon() {
      this.areaData.map(item => {
        let mu = new Polygon(item.data, {
          properties: {
            name: this.config.getTextValue(item.name)
          },
          ...this.config.option
        }).addTo(this.layer);
        this.config.openDialog &&
          mu.setInfoWindow({
            content: this.config.dialogContent(item.openDialog),
            ...this.config.dialogConfig
          });
        this.config.openAreaDialog &&
          mu
            .on("mouseover", function(e) {
              e.target.openInfoWindow(e.coordinate);
            })
            .on("mouseout", function(e) {
              e.target.closeInfoWindow();
            });
      });
    }
  }
};
</script>
