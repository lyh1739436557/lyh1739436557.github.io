<template>
  <div>
    <slot></slot>
  </div>
</template>

<script>
import { Map } from "maptalks";
export default {
  props: {
    target: {
      type: String,
      required: true
    },
    view: {
      type: Object,
      required: true
    },
    layer: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      _map: null
    };
  },
  methods: {
    createMap() {
      let options = Object.assign({}, this.view, this.layer);
      this._map = new Map(this.target, options);
      this.succeedCreate();
    },
    succeedCreate() {
      this.$emit("succeedCreateMap", this._map);
    }
  },
  mounted() {
    this.createMap();
  }
};
</script>
