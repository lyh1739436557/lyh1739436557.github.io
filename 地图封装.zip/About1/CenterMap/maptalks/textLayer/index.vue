<template>
  <div></div>
</template>

<script>
import { VectorLayer, Marker } from "maptalks";
export default {
  props: {
    // 数据来源
    pointerData: {
      type: Array,
      required: true
    },
    // 图层配置
    config: {
      type: Object,
      required: true,
      default: {}
    }
  },

  data() {
    return {
      layer: null
    };
  },

  watch: {
    pointerData: {
      handler() {
        this.updateAllMarke();
      },
      deep: true
    }
  },

  methods: {
    // 弹窗内容
    infoWindowContent(type, content) {
      let text = "";
      return text;
    },
    initLayer(map) {
      this.layer = new VectorLayer(this.config.layerId).addTo(map);
      this.initMarke();
      return this.layer;
    },
    initMarke() {
      if (this.pointerData.length === 0) {
        return;
      }
      this.pointerData.map(res => {
        let marker = new Marker(res.latLng, {
          properties: {
            name: res.name
          },
          ...this.config.layerConfig
        }).addTo(this.layer)
        this.config.openDialog && marker.on('click', function (e) {
          //update markerFill to highlight
          window.open('www.baidu.com')
        })
      });
    },
    showOrCloseLayer(bool) {
      if (bool) {
        this.layer.show();
      } else {
        this.layer.hide();
      }
    },
    updateAllMarke() {
      this.layer.clear();
      this.initMarke();
    }
  }
};
</script>
