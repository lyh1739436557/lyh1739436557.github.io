<template>
  <div></div>
</template>

<script>
import { VectorLayer, MultiLineString } from "maptalks";
export default {
  props: {
    areaData: {
      type: Array,
      required: true
    },
    config: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      layer: null
    };
  },
  watch: {
    areaData: {
      handler() {
        this.updateAllMultiLineString();
      },
      deep: true
    }
  },
  methods: {
    initLayer(map) {
      this.layer = new VectorLayer(this.config.layerId, this.config.layerConfig).addTo(map);
      this.initMultiLineString();
      return this.layer;
    },
    updateAllMultiLineString() {
      this.layer.clear();
      this.initMultiLineString();
    },
    showOrCloseLayer(bool) {
      if (bool) {
        this.layer.show();
      } else {
        this.layer.hide();
      }
    },
    // 多个区域的数据格式[[[经纬度], [经纬度]], [[经纬度], [经纬度]]]
    initMultiLineString() {
      let line = new MultiLineString(this.areaData, this.config.option).addTo(
        this.layer
      );
      line.animate(
        {
          symbol: {
            // 20 is the width of pattern.png to ensure seamless animation
            linePatternDx: 20
          }
        },
        {
          repeat: true
        }
      );
    }
  }
};
</script>
