<template>
  <div></div>
</template>

<script>
import { VectorLayer, ui } from "maptalks";
export default {
  props: {
    // 数据来源
    pointerData: {
      type: Array,
      required: true
    },
    // 图层配置
    config: {
      type: Object,
      required: true,
      default: {}
    }
  },

  data() {
    return {
      markeArr: [],
      layer: null
    };
  },

  watch: {
    pointerData: {
      handler() {
        this.updateAllMarke();
      },
      deep: true
    }
  },

  methods: {
    initLayer(map) {
      this.layer = new VectorLayer(this.config.layerId).addTo(map);
      this.initMarke(map);
      return this.layer;
    },
    initMarke(e) {
      if (this.pointerData.length === 0) {
        return;
      }
      this.markeArr.length = 0;
      this.pointerData.map(res => {
        let htmlLayer = new ui.UIMarker(res.latLng, {
          content: this.config.getTextValue(res.name),
          ...this.config.layerConfig
        }).addTo(this.layer).hide();
        this.markeArr.push(htmlLayer);
        this.config.openDialog &&
          htmlLayer.setInfoWindow({
            // title: "Marker's InfoWindow",
            content: this.config.dialogContent(res.openDialog),
            ...this.config.dialogConfig,
          });
      });
    },
    showOrCloseLayer(bool) {
      if (bool) {
        this.markeArr.map(val => {
          val.show();
        })
      } else {
        this.markeArr.map(val => {
          val.hide();
        })
      }
    },
    updateAllMarke() {
      this.layer.clear();
      this.initMarke();
    }
  }
};
</script>
