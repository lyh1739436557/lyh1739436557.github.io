import icon from '../../img/303ic_pin 3.png'
function dialogContent(res) {
  return `<div class="opendialogcoming">进：${res.coming}</div>
          <div class="opendialogback">出：${res.back}</div>
        `
}
function getTextValue(res) {
  return res
}
let config = {
  layerId: 'ldz_swly_layer',
  openDialog: true,
  dialogConfig: {
    width: 120,
    autoPan: true,
    minWidth: 120,
    minHeight: 80,
    custom: false,
    autoOpenOn: "click", //set to null if not to open when clicking on marker
    autoCloseOn: "click"
  },
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  layerConfig: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    shadowBlur: 0,
    shadowColor: 'black',
    draggable: false,
    dragShadow: false, // display a shadow during dragging
    drawOnAxis: null,
    symbol: [{
      markerFile: icon,
      markerWidth: 40,
      markerHeight: 40,
      markerDx: 0,
      markerDy: 0,
      markerOpacity: 1
    },
    {
      textFaceName: 'sans-serif',
      textName: '{name}',
      textSize: 14,
      textDy: 24,
      textFill: '#fff',
    }]
  },
}
export default config