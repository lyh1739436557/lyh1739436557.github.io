import icon from '@/assets/img/sunday.png'
let config = {
  layerId: 'layer4',
  layerConfig: {
    enableAltitude: true,
    drawAltitude: {
      polygonFill: "#1bbc9b",
      polygonOpacity: 0.3,
      lineWidth: 0
    }
  },
  option: {
    symbol: {
      lineColor: "rgba(27,203,251,0.30)",
      lineWidth: 5,
      linePatternFile: icon,
      linePatternDx: 0,
    },
    properties: {
      'altitude': 0
    }
  }
}
export default config