function dialogContent(res) {
  return `<div>${res}<div>`
}
let config = {
  layerId: 'text_layer',
  openDialog: false,
  dialogContent: dialogContent,
  layerConfig: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    shadowBlur: 0,
    shadowColor: 'black',
    draggable: false,
    dragShadow: false, // display a shadow during dragging
    drawOnAxis: null,
    symbol: {
      'textFaceName': 'sans-serif',
      'textFill': '#fff',
      'textName': '{name}',
      'textHorizontalAlignment': 'right',
      'textSize': 12,
      'textDx': -35,
      'textDy': 10,
    }
  },
}
export default config