import icon from '../../img/ic_shape.png'
function dialogContent(res) {
  return `<div>${res}<div>`
}
function getTextValue(res) {
  return "实有单位\n16.3万\n从业人员\n16.3万"
}
let config = {
  layerId: 'jyc_layer',
  openDialog: false,
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  layerConfig: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    symbol: [
      {
        markerFile: icon,
        markerWidth: 60,
        markerHeight: 60,
        markerDx: 0,
        markerDy: 10,
        markerOpacity: 1
      },
      {
        textFaceName: 'sans-serif',
        textName: '{name}',
        textSize: 10,
        textDy: -20,
        textFill: '#fff',
      }]
  },
}
export default config