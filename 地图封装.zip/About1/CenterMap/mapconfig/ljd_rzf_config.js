import icon from '../../img/303ic_pin_rizu.png'
import ewm from '../../img/qrcode.png'
function dialogContent(res) {
  return `<div class="ljd_opendialog ljd_opendialog_rzf">
            <div>
              <span>${res.coming}</span>
              <span>辖区：${res.coming}</span>
              <span>居委：${res.coming}</span>
              <span>屋主：${res.coming}</span>
            </div>
            <div>
              <img src="${ewm}" />
            </div>
          </div>`
}
function getTextValue(res) {
  return res
}
let config = {
  layerId: 'ljd_rzf_layer',
  openDialog: true,
  dialogConfig: {
    width: 300,
    autoPan: true,
    minWidth: 120,
    minHeight: 80,
    custom: false,
    autoOpenOn: "click", //set to null if not to open when clicking on marker
    autoCloseOn: "click"
  },
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  layerConfig: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    shadowBlur: 0,
    shadowColor: 'black',
    draggable: false,
    dragShadow: false, // display a shadow during dragging
    drawOnAxis: null,
    symbol: [{
      markerFile: icon,
      markerWidth: 30,
      markerHeight: 40,
      markerDx: 0,
      markerDy: 0,
      markerOpacity: 1
    },
    // {
    //   textFaceName: 'sans-serif',
    //   textName: '{name}',
    //   textSize: 14,
    //   textDy: 24,
    //   textFill: '#fff',
    // }
  ]
  },
}
export default config