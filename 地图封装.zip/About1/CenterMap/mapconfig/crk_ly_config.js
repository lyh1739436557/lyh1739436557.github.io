// import icon from '../../img/303ic_pin 3.png'
function dialogContent(res) {
  return `<div class="areaopendialog">${res.title}</div>
          <div class="opendialogcoming">进：2312</div>
          <div class="opendialogback">出：3840</div>
        `
}
function getTextValue(res) {
  return res
}
let config = {
  layerId: 'crk_ly_layer',
  openDialog: true,
  dialogConfig: {
    width: 200,
    autoPan: true,
    minWidth: 120,
    minHeight: 80,
    custom: false,
    autoOpenOn: "click", //set to null if not to open when clicking on marker
    autoCloseOn: "click"
  },
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  openAreaDialog: false,
  option: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    shadowBlur: 0,
    shadowColor: "black",
    draggable: false,
    dragShadow: false, // display a shadow during dragging
    drawOnAxis: null, // force dragging stick on a axis, can be: x, y
    symbol: [{
      lineColor: "rgba(243, 52, 20, .8)",
      lineWidth: 0,
      polygonFill: "rgba(243, 52, 20, .8)",
      polygonOpacity: 0.6
    },
    {
      textFaceName: 'sans-serif',
      textName: '{name}',
      textSize: 14,
      textDy: 24,
      textFill: '#fff',
    }]
  }
}
export default config