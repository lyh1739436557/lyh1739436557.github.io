import icon from '../../img/ic_shape.png'
function dialogContent(res) {
  return `<div class="opendialogcoming1">户籍人口：15万人</div>
          <div class="opendialogback1">来沪人口：1万人</div>
          <div class="opendialogcoming1">境外人口：3000人</div>
          `
}
function getTextValue(res) {
  return "实有人口\n16.3万"
}
let config = {
  layerId: 'rkgk_layer',
  openDialog: true,
  dialogConfig: {
    width: 200,
    autoPan: true,
    minWidth: 120,
    minHeight: 80,
    custom: false,
    autoOpenOn: "click", //set to null if not to open when clicking on marker
    autoCloseOn: "click"
  },
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  layerConfig: {
    visible: true,
    editable: true,
    cursor: 'pointer',
    symbol: [
      {
        markerFile: icon,
        markerWidth: 40,
        markerHeight: 40,
        markerDx: 0,
        markerDy: 0,
        markerOpacity: 1
      },
      {
        textFaceName: 'sans-serif',
        textName: '{name}',
        textSize: 10,
        textDy: -20,
        textFill: '#fff',
      }]
  },
}
export default config