// import icon from '../../img/303ic_pin 3.png'
function dialogContent(res) {
  return `<div class="areaopendialog">${res.title}</div>
          <div class="opendialogcoming">进：2312</div>
          <div class="opendialogback">出：3840</div>
        `
}
function getTextValue(res) {//  LR UD
  if (res.JunctureDirection == "limgrct") {
    return `<div class="in_out_layer-limgrct">
            <div class="in_out_layer-limgrct-img"></div>
            <div class="in_out_layer-limgrct-container">
              <div class="in_out_layer-limgrct-container-title">${res.name}</div>
              <div class="in_out_layer-limgrct-container-in">进：${res.inPerson}</div>
              <div class="in_out_layer-limgrct-container-out">出：${res.outPerson}</div>
            </div>
          </div>
        `
  } else if (res.JunctureDirection == "lctrimg") {
    return `<div class="in_out_layer-lctrimg">
            <div class="in_out_layer-lctrimg-img"></div>
            <div class="in_out_layer-lctrimg-container">
              <div class="in_out_layer-lctrimg-container-title">${res.name}</div>
              <div class="in_out_layer-lctrimg-container-in">进：${res.inPerson}</div>
              <div class="in_out_layer-lctrimg-container-out">出：${res.outPerson}</div>
            </div>
          </div>
        `
  } else if (res.JunctureDirection == "uctdimg") {
    return `<div class="in_out_layer-uctdimg">
            <div class="in_out_layer-uctdimg-container">
              <div class="in_out_layer-uctdimg-container-title">${res.name}</div>
              <div class="in_out_layer-uctdimg-container-in">进：${res.inPerson}</div>
              <div class="in_out_layer-uctdimg-container-out">出：${res.outPerson}</div>
            </div>
            <div class="in_out_layer-uctdimg-img"></div>
          </div>
        `
  } else if (res.JunctureDirection == "uimgdct") {
    return `<div class="in_out_layer-uimgdct">
            <div class="in_out_layer-uimgdct-img"></div>
            <div class="in_out_layer-uimgdct-container">
              <div class="in_out_layer-uimgdct-container-title">${res.name}</div>
              <div class="in_out_layer-uimgdct-container-in">进：${res.inPerson}</div>
              <div class="in_out_layer-uimgdct-container-out">出：${res.outPerson}</div>
            </div>
          </div>
        `
  }
}
let config = {
  layerId: 'crk_jck_layer',
  openDialog: false,
  dialogConfig: {
    width: 200,
    autoPan: true,
    minWidth: 120,
    minHeight: 80,
    custom: false,
    autoOpenOn: "click", //set to null if not to open when clicking on marker
    autoCloseOn: "click"
  },
  dialogContent: dialogContent,
  getTextValue: getTextValue,
  option: {
    'draggable': true,
    'single': false,
  }
}
export default config