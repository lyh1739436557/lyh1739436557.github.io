import { TileLayer } from "maptalks";
let config = {
  target: "person-center-map",
  options: {
    center: [121.48454, 31.2007],
    zoom: 14,
    pitch: 30,
    bearing: -10,
  },
  baseLayer: {
    baseLayer: new TileLayer("base", {
      urlTemplate:
        "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
      subdomains: ["a", "b", "c", "d"]
    })
  }
}

export default config
