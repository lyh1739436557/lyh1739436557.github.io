<template>
  <div class="actual-person">
    <left-side></left-side>
    <center-map></center-map>
    <right-side></right-side>
  </div>
</template>

<script>
import LeftSide from './LeftSide'
import RightSide from './RightSide'
import CenterMap from './CenterMap'
export default {
  data(){
    return {
      isShow:false
    }
  },
  components: {
    LeftSide,
    RightSide,
    CenterMap
  }
};
</script>

<style lang="scss" scope>
  .actual-person{
    height: 100%;
    width: 3840px;
    background: #01144A;
    display: flex;
    flex-flow: row nowrap;
    position: relative;
  }
</style>
